import requests
import pandas as pd


response = requests.get("https://search.worldbank.org/api/v2/wds?format=json&includepublicdocs=1&fl=docna,lang,docty,repnb,docdt,doc_authr,available_in&rows=80&proid=P169267&apilang=en&fct=countryname&os=0&proid=P169267&apilang=en&fct=countryname")
response.json()
data = pd.DataFrame(response.json()['documents']).transpose().dropna(how='all')
data.loc[data.docty.str.contains("Project Information Document"),'url']
data.loc['D31700979','url']